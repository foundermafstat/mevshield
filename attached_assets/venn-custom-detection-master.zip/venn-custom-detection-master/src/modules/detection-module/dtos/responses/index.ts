export * from './detect-response'
